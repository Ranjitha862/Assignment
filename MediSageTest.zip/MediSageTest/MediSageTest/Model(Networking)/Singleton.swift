//
//  Singleton.swift
//  MediSageTest
//
//  Created by Ranjitha S on 04/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation

class Singleton {
    
    static let sharedInstance = Singleton()
    private init() { }
    
    var postListData = [Model]()
    var titleSingleton: [String] = []
    var bodySingleton: [String] = []
    var index: [Int] = []
}
