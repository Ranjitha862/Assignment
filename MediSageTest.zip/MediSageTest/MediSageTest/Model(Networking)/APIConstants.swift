//
//  APIConstants.swift
//  MediSageTest
//
//  Created by Ranjitha S on 04/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation

class APIConstants{
    
    static var baseServer: String = "https://jsonplaceholder.typicode.com/posts"
    
    class func APIList() -> String {
           return "\(baseServer)"
       }
}
