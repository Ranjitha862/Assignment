//
//  Model.swift
//  MediSageTest
//
//  Created by Ranjitha S on 04/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import Foundation

class Model: NSObject {
    
    var id: Int = 0
    var title: String = ""
    var explanation: String = ""
    
}
