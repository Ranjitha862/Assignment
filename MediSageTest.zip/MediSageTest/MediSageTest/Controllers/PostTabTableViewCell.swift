//
//  PostTabTableViewCell.swift
//  MediSageTest
//
//  Created by Ranjitha S on 04/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class PostTabTableViewCell: UITableViewCell {

    @IBOutlet weak var starButton: UIButton?
    @IBOutlet weak var cardView: UIView?
    @IBOutlet weak var titleLabel: UILabel?
    @IBOutlet weak var explanationLabel: UILabel?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
