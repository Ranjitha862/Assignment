//
//  SecondViewController.swift
//  MediSageTest
//
//  Created by Ranjitha S on 03/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit
import CoreData

class SecondViewController: UIViewController, UISearchBarDelegate {
    
    @IBOutlet weak var tblView: UITableView?
    @IBOutlet weak var searchBar: UISearchBar?
    
    fileprivate var listModel : [Model] = []
    var postTitle: String?
    var filteredData = [Model]()
    fileprivate var isSearching = false
    
    var post: Post? {
        didSet {
            guard let post = post else { return }
            postTitle = "\(String(describing: post.title))"
        }
    }
    lazy var coreDataStack = CoreDataStack(modelName: "MediSageTest")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setData()
    }
    
    func setData(){
        
        self.navigationItem.title = "Post"
        let button1 : UIButton = UIButton.init(type: .custom)
        button1.setTitle("Log Out", for: .normal)
        button1.addTarget(self, action: #selector(logOutTapped), for: .touchUpInside)
        button1.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        button1.setTitleColor(UIColor.blue, for: .normal)
        let addButton = UIBarButtonItem(customView: button1)
        
        navigationItem.setRightBarButtonItems([addButton], animated: true)
        isSearching = false
        searchBar?.text = ""
        searchBar?.delegate = self
        tblView?.delegate = self
        tblView?.dataSource = self
        self.tblView?.tableFooterView = UIView()
        
        searchBar?.alwaysShowCancelButton()
        
        let vc = UINib(nibName: "PostTabTableViewCell", bundle: nil)
        tblView?.register(vc, forCellReuseIdentifier: "PostTabTableViewCell")
        
        APICall()
    }
    
    @objc func logOutTapped(){
        
        if let loginVc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
            self.hidesBottomBarWhenPushed  = true
            self.navigationController?.pushViewController(loginVc, animated: true)
            self.hidesBottomBarWhenPushed  = false
        }
    }
}

extension SecondViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isSearching == true{
            return filteredData.count
        }else{
            return listModel.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellMain = UITableViewCell()
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTabTableViewCell") as? PostTabTableViewCell else{
            return UITableViewCell()
        }
        var data = listModel[indexPath.row]
        
        if self.isSearching {
            data = self.filteredData[indexPath.row]
        } else {
            data = self.listModel[indexPath.row]
        }
        
        cell.titleLabel?.text = data.title
        cell.explanationLabel?.text = data.explanation
        cell.starButton?.titleLabel?.tag = indexPath.row
        
        
        if data.id == indexPath.row{
            cell.starButton?.setImage(UIImage(systemName: "star.fill"), for: .normal)
            cell.starButton?.isHidden = false
        }else{
            cell.starButton?.isHidden = true
        }
        cellMain = cell
        return cellMain
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = listModel[indexPath.row]
        
        Singleton.sharedInstance.titleSingleton.append(data.title)
        Singleton.sharedInstance.bodySingleton.append(data.explanation)
        data.id = indexPath.row
        
        let cell = tableView.cellForRow(at: indexPath) as! PostTabTableViewCell
        cell.starButton?.isHidden = false
        cell.starButton?.setImage(UIImage(systemName: "star.fill"), for: .normal)
        self.tblView?.reloadData()
    }
    
    private func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        if cell.isSelected {
            cell.isSelected = true
        } else {
            cell.isSelected = false
        }
    }
}


extension SecondViewController{
    
    func APICall(){
        
        let url = APIConstants.APIList()
        
        RESTfulServices.makeRESTCall(endpointURL: url, requestMethod: "GET", customCompletionHandler: getList)
    }
    
    fileprivate func getList(data : Data?, response : URLResponse?, error : Error?) -> Void {
        
        if error != nil {
            
            //        if(self.numRetries < 3) {
            //
            //            DispatchQueue.main.async {
            //                self.dismissHUD(isAnimated: true)
            //            }
            
            //   } else {
            
            //            DispatchQueue.main.async {
            //                self.dismissHUD(isAnimated: true)
            //            }
            
            //}
            
            
        } else  {
            
            do {
                
                if let httpResponse = response as? HTTPURLResponse {
                    
                    if (httpResponse.statusCode == 401 || httpResponse.statusCode == 402) {
                        
                        return
                    }
                }
                
                let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String:Any]]
                
                let context = ((UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext)!
                let newToDo = Post(context: context)
                
                for obj in parsedData {
                    
                    let context = ((UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext)!
                    let newToDo = Post(context: context)
                    
                    let model1 = Model()
                    
                    if let id = obj["id"] as? Int{
                        model1.id = id
                    }
                    
                    if let title = obj["title"] as? String {
                        model1.title = title
                        newToDo.title = title as NSObject
                    }
                    
                    if let body = obj["body"] as? String {
                        model1.explanation = body
                    }
                    
                    listModel.append(model1)
                    Singleton.sharedInstance.postListData.append(model1)
                    (UIApplication.shared.delegate as? AppDelegate)?.saveContext()
                }
                
                self.tblView?.reloadData()
            }catch let errorLocal as NSError {
                
            }
        }
    }
    
}

extension Array where Element:Equatable {
    func removeDuplicates() -> [Element] {
        var result = [Element]()
        
        for value in self {
            if result.contains(value) == false {
                result.append(value)
            }
        }
        
        return result
    }
}

//extension SecondViewController{
//
//    func loadPost() {
//           let postFetchRequest: NSFetchRequest<Post> = Post.fetchRequest() //make a Person Entity fetch request
//           do {
//               let results = try coreDataStack.mainContext.fetch(postFetchRequest)
//               if results.count > 0 {
//                print(results.count)
//                post = results.first
//               } else { //no person found
//                   post = Post(context: coreDataStack.mainContext)
//                   coreDataStack.saveContext()
//               }
//           } catch let error as NSError {
//               print("Error: \(error) description: \(error.userInfo)")
//           }
//       }
//
//    @objc func handleSavePerson() {
//        let data = [listModel]
//
//        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
//            let post = Post(context: context)
//            for i in data{
//
//            }
//        }
//        guard let name = postTitle, !name.isEmpty else { return }
//        post?.title = name as NSObject
//
//        //save the managed object context
//        do {
//            try coreDataStack.mainContext.save()
//        } catch let error as NSError {
//            print("Error: \(error), description: \(error.userInfo)")
//        }
//    }
//}


extension SecondViewController: UITextViewDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        let searchString = searchText.trimWhiteSpace()
        searchBar.showsCancelButton = true
        if searchText == "" {
            isSearching = false
            view.endEditing(true)
            tblView?.reloadData()
            
        } else {
            
            if searchString != "", searchString.count > 0 {
                let getFilterData = listModel.filter {
                    return $0.title.range(of: searchString, options: .caseInsensitive) != nil
                }
                isSearching = true
                filteredData = getFilterData
                self.tblView?.reloadData()
            }
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.text = ""
        searchBar.showsCancelButton = true
        if searchBar.text == "" {
            view.endEditing(true)
            
            if searchBar.text == "" {
                isSearching = false
                view.endEditing(true)
                tblView?.reloadData()
            }
        }
    }
}

extension String {
    func trimWhiteSpace() -> String {
        let string = self.trimmingCharacters(in: .whitespacesAndNewlines)
        return string
    }
}

extension UISearchBar {
    
    func alwaysShowCancelButton() {
        for subview in self.subviews {
            for ss in subview.subviews {
                if #available(iOS 13.0, *) {
                    for s in ss.subviews {
                        self.enableCancel(with: s)
                    }
                }else {
                    self.enableCancel(with: ss)
                }
            }
        }
    }
    private func enableCancel(with view:UIView) {
        if NSStringFromClass(type(of: view)).contains("UINavigationButton") {
            (view as! UIButton).isEnabled = true
        }
    }
}
