//
//  ThirdViewController.swift
//  MediSageTest
//
//  Created by Ranjitha S on 04/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView?
    
    var head: String = ""
    fileprivate var listModel : [Model] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

      setData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Singleton.sharedInstance.titleSingleton = Array(Set(Singleton.sharedInstance.titleSingleton))
        tblView?.reloadData()
    }
    
    func setData(){
        
        tblView?.delegate = self
        tblView?.dataSource = self
        self.tblView?.tableFooterView = UIView()
        self.navigationItem.title = "Favourites"
        let vc = UINib(nibName: "PostTabTableViewCell", bundle: nil)
        tblView?.register(vc, forCellReuseIdentifier: "PostTabTableViewCell")
    }
     
}
  extension ThirdViewController: UITableViewDelegate, UITableViewDataSource{
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return Singleton.sharedInstance.titleSingleton.count
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return UITableView.automaticDimension
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            var cellMain = UITableViewCell()
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTabTableViewCell") as? PostTabTableViewCell else{
                return UITableViewCell()
            }
            
            let data = Singleton.sharedInstance.titleSingleton[indexPath.row]
            let body = Singleton.sharedInstance.bodySingleton[indexPath.row]
            cell.titleLabel?.text = data
            cell.explanationLabel?.text = body
            cell.starButton?.isHidden = true
            
            cellMain = cell
            return cellMain
        }
    }
