//
//  ViewController.swift
//  MediSageTest
//
//  Created by Ranjitha S on 03/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var usernameTextfield: UITextField?
    @IBOutlet weak var passwordTextField: UITextField?
    @IBOutlet weak var submitButton: UIButton?
    
    var email: String = ""
    var password: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setData()
    }
    
    func setData(){
        
        usernameTextfield?.textContentType = UITextContentType.emailAddress
        passwordTextField?.textContentType = UITextContentType.password
        usernameTextfield?.delegate = self
        passwordTextField?.delegate = self
        usernameTextfield?.tag = 0
        passwordTextField?.tag = 1
        submitButton?.isEnabled = false
        submitButton?.backgroundColor = UIColor.lightGray
        submitButton?.addTarget(self, action: #selector(submitTapped), for: .touchUpInside)
        self.navigationController?.navigationBar.isHidden = true
        usernameTextfield?.addDoneButtonOnKeyboard()
        passwordTextField?.addDoneButtonOnKeyboard()
        submitButton?.layer.cornerRadius = 5.0
    }
    
    func alert(){
        
        let alert = UIAlertController(title: "Error", message: "password length 8 - 15", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if emailPred.evaluate(with: email) == false{
            let alert = UIAlertController(title: "Error", message: "Please enter valid username", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        return emailPred.evaluate(with: email)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        submitButton?.isEnabled = false
        submitButton?.backgroundColor = UIColor.lightGray
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.tag == 0{
            isValidEmail(textField.text ?? "")
            email = textField.text ?? ""
            
        }else if textField.tag == 1{
            password = textField.text ?? ""
            
            if textField.text?.count ?? 0 < 8 || textField.text?.count ?? 0 > 15{
                let alert = UIAlertController(title: "Error", message: "Please enter Password length between 8-15", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }
        }
        validations()
        
    }
    
    func validations(){
        
        if isValidEmail(email) == true && password.count > 8{
            submitButton?.isEnabled = true
            submitButton?.backgroundColor = UIColor.systemBlue
        } else if password.count < 8 && password.count > 15{
            alert()
            submitButton?.isEnabled = false
            submitButton?.backgroundColor = UIColor.lightGray
        }else if isValidEmail(email) != true{
            submitButton?.isEnabled = false
            submitButton?.backgroundColor = UIColor.lightGray
        }
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField.tag == 1{
            let maxLength = 15
            let currentString: NSString = textField.text! as NSString
            let newString: String =
                currentString.replacingCharacters(in: range, with: string) as String
            
            return newString.count <= maxLength
        }
        return true
    }
    
    @objc func submitTapped(){
        if isValidEmail(email) == true && password.count > 8{
            if let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController {
                
                self.navigationController?.pushViewController(secondViewController, animated: true)
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
}


extension UITextField {
    
    func addDoneButtonOnKeyboard() {
        let keyboardToolbar = UIToolbar()
        keyboardToolbar.sizeToFit()
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
                                            target: nil, action: nil)
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done,
                                         target: self, action: #selector(resignFirstResponder))
        keyboardToolbar.items = [flexibleSpace, doneButton]
        self.inputAccessoryView = keyboardToolbar
    }
}
