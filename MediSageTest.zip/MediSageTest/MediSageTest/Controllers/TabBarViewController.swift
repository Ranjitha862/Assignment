//
//  TabBarViewController.swift
//  MediSageTest
//
//  Created by Ranjitha S on 03/03/21.
//  Copyright © 2021 Ranjitha S. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.delegate = self
        self.tabBar.isTranslucent = false
        
        navigationItem.hidesBackButton = true
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for:.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.layoutIfNeeded()
        
        setTabBarItems()
    }
    

    func setTabBarItems(){
        
        let myTabBarItem = (self.tabBar.items?[0])! as UITabBarItem
        myTabBarItem.image = UIImage(systemName: "house")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        myTabBarItem.selectedImage = UIImage(systemName: "house.fill")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        
        let myTabBarItem2 = (self.tabBar.items?[1])! as UITabBarItem
        myTabBarItem2.image = UIImage(systemName: "hourglass")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        myTabBarItem2.selectedImage = UIImage(systemName: "hourglass.fill")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        
        
    }

}
